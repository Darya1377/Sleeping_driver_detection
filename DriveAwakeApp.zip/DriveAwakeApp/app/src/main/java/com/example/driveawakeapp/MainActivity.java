package com.example.driveawakeapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView res;
    private EditText num1, num2;
    private Button butt, btn_second, f1, f2;

    private FrameLayout fragment_field;
    private NewFragment newFragment = new NewFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView main_text = findViewById(R.id.main_text);
        Button btn_second = findViewById(R.id.btn_second);
        Button f1 = findViewById(R.id.f1);
        Button f2 = findViewById(R.id.f2);
        fragment_field = findViewById(R.id.fragment_field);

        setNewFragment(newFragment);

        f1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setNewFragment(newFragment);
            }
        });

        f2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SecondFragment secondFragment = new SecondFragment();
                setNewFragment(secondFragment);
            }
        });
        btn_second.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
//        res = findViewById(R.id.textView);
//        num1 = findViewById(R.id.number_field1);
//        num2 = findViewById(R.id.number_field2);
//        butt = findViewById(R.id.button);

        butt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showInfo(main_text.getText().toString(), btn_second);
                showInfoAlert("Do you want to close the app?");
            }
        });
    }

    private void setNewFragment(Fragment fragment) {
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fragment_field, newFragment);
        ft.addToBackStack(null);
        ft.commit();
    }

    public void btnClick(View v){
        showInfo(((Button)v).getText().toString(), ((Button)v));
    }

    private void showInfoAlert(String text){
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("some hint")
                .setMessage(text)
                .setCancelable(false)
                .setPositiveButton("fine", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        finish();
                    }
                })
                .setNegativeButton("nope", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });
        AlertDialog dialog = builder.create();
        dialog.show();

    }
    private void showInfo(String text, Button btn){
        btn.setText("Process started");
        btn.setBackgroundTintList(ColorStateList.valueOf(Color.GRAY));
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    public void startNewActivity(View v){
        Intent intent = new Intent(this, SecondActiviity.class);
        startActivity(intent);
    }

}