package com.example.driveawakeapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DesignSample extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_design_sample);
    }
}